---
title: "Escenario de respuesta a incidentes - DELTA LOGÍSTICA SPA"
course: INF44 - Gestión de la Seguridad
lesson: "15"
---

# Escenario - DELTA LOGÍSTICA SPA (empresa ficticia), ransomware

## Antecedentes

DELTA LOGÍSTICA SPA distribuye productos para comercios de la región (lecciones 13 y 14). Después del corte eléctrico de octubre, la gerencia aprobó un BIA y estrategias de recuperación para el **presupuesto 2027**: réplica del ERP y del directorio en la nube, respaldos incrementales cada hora más una copia diaria inmutable fuera de la sede, y un segundo enlace de Internet. **Ninguna está implementada todavía.** La réplica puede copiar también el cifrado; una copia limpia necesita protección y verificación independientes.

Objetivos aprobados en el BIA (lección 14):

| Proceso | MTPD | RTO | RPO |
| --- | --- | --- | --- |
| Venta en línea con stock confirmado | 4 h | 3 h | 1 h |
| Despacho y logística | 8 h | 7 h | 4 h |
| Facturación electrónica | 24 h (8 h en cierre de mes) | 7 h | 8 h |

Capacidad comprobada: restaurar el ERP desde el NAS toma **7 h** (6 de restauración y 1 de validación) y requiere que antes la identidad (directorio) esté operativa, lo que se estima en **2 h**. Tras recuperar el ERP, la integración con transportistas necesita una hora más. El respaldo es diario, a las 23:00, y se guarda en el NAS, que está en la misma sala y la misma red que los servidores.

## Cómo responde hoy DELTA

DELTA no tiene un plan de respuesta a incidentes. Su único procedimiento escrito dice:

> «Ante una falla informática, el usuario avisa a la mesa de ayuda. La mesa de ayuda informa al jefe de TI, quien resuelve y avisa a la gerencia si lo considera necesario.»

Otros datos útiles:

- **Monitoreo:** hay un antivirus con consola central (EDR) que genera alertas, pero nadie las revisa fuera del horario de oficina (08:00 a 18:00).
- **Acceso remoto:** los transportistas externos entran por VPN con cuentas propias (`tr-rutasur`, `tr-norte` y otras) para consultar despachos. Las cuentas de transportistas **no tienen MFA**.
- **Personas clave:** gerente general, gerente comercial, jefe de TI (con un analista), encargada de bodega, contadora, asesor legal externo. No hay vocero designado.
- **Clientes:** RETAIL SUR es el cliente mayorista más importante (lección 14).
- **Regulación:** DELTA no ha sido calificada como operador de importancia vital (Ley 21.663). El caso no determina si alguna de sus actividades constituye un servicio esencial; el asesor legal debe comprobarlo y evaluar las obligaciones de reporte y protección de datos. La reforma de la Ley 21.719 comienza a regir el 01-12-2026, después del incidente simulado.

## El ejercicio de mesa

La gerencia contrató un ejercicio de mesa para preparar su primer plan de respuesta. El ejercicio recrea un incidente que **ya ocurrió**, el jueves 12-11-2026, pero las parejas no ven lo que DELTA hizo hasta terminar de decidir:

1. **Juego de roles:** cada pareja lee las tres inyecciones, una a la vez, en `../actividad.md` y decide qué haría DELTA si tuviera un buen plan. Una persona coordina, la otra lidera lo técnico y ambas consideran negocio y comunicaciones.
2. **Resultados:** después de responder I3, la pareja lee la cronología incluida en `../actividad.md` (el CSV queda como copia para análisis adicional). Con ella mide los tiempos y los compara con los objetivos.
3. **Playbook y mitigación:** con las brechas medidas, cada pareja propone un playbook de ransomware de una página y un plan de mitigación verificable.

Los roles del ejercicio son:

| Rol | Responde por |
| --- | --- |
| **Coordinador del incidente** | Declarar el incidente, priorizar, decidir y llevar el tiempo |
| **Líder técnico** | Contención, preservación de evidencia y recuperación técnica |
| **Enlace de negocio y comunicaciones** | Dueños de proceso, clientes, prensa, asesor legal y gerencia |

Los datos son sintéticos. No hay una única respuesta correcta: se valoran decisiones con autoridad clara, que contengan sin destruir evidencia, que se midan con el registro y que se conviertan en acciones verificables.
