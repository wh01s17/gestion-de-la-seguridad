---
title: "Material Lección 15 - Respuesta a incidentes y mitigación"
course: INF44 - Gestión de la Seguridad
lesson: "15"
---

# Material Lección 15 - DELTA LOGÍSTICA SPA

La única entrega solicitada es una copia respondida de `../actividad.md` por pareja. Ese archivo es autocontenido: trae el escenario, las tres inyecciones, la cronología, las tablas de respuesta y los criterios de trabajo. Este paquete conserva los datos fuente para verificar el caso.

| Archivo | Contenido | Cuándo se usa |
| --- | --- | --- |
| `escenario.md` | Antecedentes ampliados del caso | Archivo fuente |
| `registro-incidente.csv` | Cronología completa con fuentes y responsables | Archivo fuente |
| `manifest_entrega.sha256` | Hashes de los archivos del material | Para verificar integridad |

Las tres inyecciones están en `../actividad.md` y se leen en orden. Para conservar el efecto del ejercicio, no adelanten la lectura de la Parte 2.

Para leer el registro en pantalla con columnas alineadas:

```bash
column -s, -t < registro-incidente.csv
```

Verificar integridad:

```bash
sha256sum -c manifest_entrega.sha256
```

Las respuestas se escriben en las tablas de `../actividad.md`.
